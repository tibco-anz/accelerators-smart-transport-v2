<!--
title: Reply
weight: 4601
-->

# Reply
This activity allows you to reply to a trigger invocation and map output values. After replying to the trigger, this activity will allow the action to continue further.

## Installation

### Flogo Enterprise for Flogo on TCI

Upload activity through UI extension by using below URL
```
github.com/lixingwang/flogo-contrib/activity/actreply
```

## Configuration

### Input Settings:

Please do configure input Settings schema same with flow output.  You can just copy flow outout schema to this activity input schema.